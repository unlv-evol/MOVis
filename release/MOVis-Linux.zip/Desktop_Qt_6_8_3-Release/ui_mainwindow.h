/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.8.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLineEdit *lineText;
    QPushButton *btnSubmit;
    QLabel *label;
    QLineEdit *lineText_2;
    QLabel *label_2;
    QPlainTextEdit *plainTextEdit;
    QLabel *label_4;
    QLabel *imageLabel;
    QPushButton *btnExtra;
    QLineEdit *lineText_3;
    QLabel *label_6;
    QPushButton *oldResults;
    QPushButton *hideButton;
    QPushButton *divDateButton;
    QGroupBox *dateBox;
    QDateEdit *dateEdit;
    QLabel *label_5;
    QDateEdit *dateInput;
    QLabel *label_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(791, 603);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        lineText = new QLineEdit(centralwidget);
        lineText->setObjectName("lineText");
        lineText->setGeometry(QRect(30, 90, 131, 24));
        btnSubmit = new QPushButton(centralwidget);
        btnSubmit->setObjectName("btnSubmit");
        btnSubmit->setGeometry(QRect(210, 120, 80, 24));
        label = new QLabel(centralwidget);
        label->setObjectName("label");
        label->setGeometry(QRect(30, 70, 111, 20));
        lineText_2 = new QLineEdit(centralwidget);
        lineText_2->setObjectName("lineText_2");
        lineText_2->setGeometry(QRect(210, 90, 151, 24));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(210, 70, 131, 20));
        plainTextEdit = new QPlainTextEdit(centralwidget);
        plainTextEdit->setObjectName("plainTextEdit");
        plainTextEdit->setGeometry(QRect(433, 49, 341, 501));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(430, 30, 91, 16));
        imageLabel = new QLabel(centralwidget);
        imageLabel->setObjectName("imageLabel");
        imageLabel->setGeometry(QRect(20, 230, 49, 16));
        btnExtra = new QPushButton(centralwidget);
        btnExtra->setObjectName("btnExtra");
        btnExtra->setGeometry(QRect(10, 530, 141, 24));
        lineText_3 = new QLineEdit(centralwidget);
        lineText_3->setObjectName("lineText_3");
        lineText_3->setGeometry(QRect(30, 40, 131, 24));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(30, 20, 111, 20));
        oldResults = new QPushButton(centralwidget);
        oldResults->setObjectName("oldResults");
        oldResults->setGeometry(QRect(210, 40, 151, 24));
        hideButton = new QPushButton(centralwidget);
        hideButton->setObjectName("hideButton");
        hideButton->setGeometry(QRect(690, 20, 80, 24));
        divDateButton = new QPushButton(centralwidget);
        divDateButton->setObjectName("divDateButton");
        divDateButton->setGeometry(QRect(30, 120, 131, 24));
        dateBox = new QGroupBox(centralwidget);
        dateBox->setObjectName("dateBox");
        dateBox->setGeometry(QRect(30, 150, 341, 80));
        dateEdit = new QDateEdit(dateBox);
        dateEdit->setObjectName("dateEdit");
        dateEdit->setGeometry(QRect(10, 40, 131, 25));
        dateEdit->setCalendarPopup(false);
        label_5 = new QLabel(dateBox);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(10, 20, 161, 20));
        dateInput = new QDateEdit(dateBox);
        dateInput->setObjectName("dateInput");
        dateInput->setGeometry(QRect(170, 40, 131, 25));
        label_3 = new QLabel(dateBox);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(170, 20, 161, 20));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 791, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        btnSubmit->setText(QCoreApplication::translate("MainWindow", "Submit", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Source Variant", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Target Variant", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Token List", nullptr));
        imageLabel->setText(QString());
        btnExtra->setText(QCoreApplication::translate("MainWindow", "Advanced Results", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Results Folder Name", nullptr));
        oldResults->setText(QCoreApplication::translate("MainWindow", "View Previous Results", nullptr));
        hideButton->setText(QCoreApplication::translate("MainWindow", "Hide", nullptr));
        divDateButton->setText(QCoreApplication::translate("MainWindow", "Get Divergence Date", nullptr));
        dateBox->setTitle(QCoreApplication::translate("MainWindow", "Date Information", nullptr));
        dateEdit->setDisplayFormat(QCoreApplication::translate("MainWindow", "M/d/yyyy", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Initial Date & Time", nullptr));
        dateInput->setDisplayFormat(QCoreApplication::translate("MainWindow", "M/d/yyyy", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "Divergence Date & Time", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
